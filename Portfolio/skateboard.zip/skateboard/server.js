var express = require('express');
var app = express();
var fs = require("fs");
var cors = require('cors');
app.use(cors());

/*API list all users*/
app.get('/listUsers', function (req,res,next) {
   console.log( "list all users" );
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
	 if (!err){
       console.log( data );
       res.send( data );
       res.end(  );
	 }
	 else{
	   console.log('no user' );	
	   res.end(  );
	 }
   });
})

/*API List all user reservation*/
app.get('/listAll', function (req,res,next) {
   console.log( "List all user reservation" );
   fs.readFile( __dirname + "/" + "reservation.json", 'utf8', function (err, data) {
     if (!err){
	  userdata = JSON.parse( data );
	  if (userdata.length > 0){
        console.log( data );
        res.send( data );
        res.end();
	  }
	  else{
        console.log('No reservation' );	
	    res.send('No reservation');
		res.end();
      }
	}
   });
})

/*API List one user reservation*/
app.get('/listOne/:usernameValue', function (req,res,next) {
   
   console.log( "List one user reservation" );
   console.log(req.params.usernameValue);
   fs.readFile( __dirname + "/" + "reservation.json", 'utf8', function (err, data) {
	if (!err){
      userdata = JSON.parse( data );
      var users = [];
      for (var i = 0; i < userdata.length; i++) {
         if (userdata[i].name == req.params.usernameValue){ 
          users.push(userdata[i]);	 	  
         }		  
	  }
	
	  if (users.length > 0){
		 var json_str = JSON.stringify(users)
		 console.log( json_str );
		 res.send(json_str);
		 res.end(); 
	  }
	  else{
        console.log('No reservation' );	
	    res.send('No reservation');
	    res.end();
      }		
	 
	}
	else{
	 console.log('No reservation' );	
	 res.send('No reservation');
	 res.end();	
	}
   });
})

/*API Add user*/
app.post('/addUser/:usernameValue', function (req,res,next) {
	 console.log( "addUser:" );
	 console.log(req.params.usernameValue);
     fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
	 var newUsers = [];
	 let userFind =0;
	 if (!err){
        newUsers =JSON.parse(data)
        for (var i = 0; i <newUsers.length; i++) {
		  if (newUsers[i].name == req.params.usernameValue)
		  userFind =1;
	    }
	 }
	if (userFind == 0){
	   var person = new Object();
       person.name=req.params.usernameValue;
       newUsers.push(person);
	   var json_str = JSON.stringify(newUsers);
	   fs.writeFile('users.json',json_str, function(err) {
		if(err){
           throw err;
        }  
		else{
		 console.log(`User has added`);
		 console.log(json_str);
		 res.send(`User has added`);
		 res.end();
		}
	 });
   }
   else{
	 console.log(`User has existed`);
	 res.send(`User has existed`);
	 res.end();
     	   
   }
 });
})

/*API Add user reservation*/
app.post('/addReservation/username/:usernameValue/startDate/:startDateValue/startTime/:startTimeValue/Hours/:hourValue', function (req,res,next) {
	 console.log( "addReservation:" );
	 fs.readFile( __dirname + "/" + "reservation.json", 'utf8', function (err, data) {
	 var reservation = [];
	 let found =0;
	 if (!err){
        reservation =JSON.parse(data)
		for (var i = 0; i <reservation.length; i++) {
			
			 if (reservation[i].name == req.params.usernameValue ){
				 found =1;
			 }
	    }
		
	}
	if (found == 0){
	   var rObject = new Object();
       rObject.name= req.params.usernameValue;
	   rObject.startDate= req.params.startDateValue;
	   rObject.startTime= req.params.startTimeValue;
	   rObject.hours= req.params.hourValue
	   reservation.push(rObject);
	
	   var json_str = JSON.stringify(reservation);
       fs.writeFile('reservation.json',json_str, function(err) {
	   if(err){
          throw err;
       }
	   else{
		 console.log(`Reservation has added`);
		 console.log(json_str);
		 res.send(`Reservation has added`);
		 res.end();
		}  
	 });
	}
	else{
	  console.log(` User reservation has existed`);
	  res.send(`User reservation has existed`);
	  res.end();
	}
 });
})

/*API Update user reservation*/
app.put('/updateReservation/username/:usernameValue/startDate/:startDateValue/startTime/:startTimeValue/Hours/:hourValue', function (req,res,next) {
	 console.log( "updateReservation:" );
	 let found =0;
	 fs.readFile( __dirname + "/" + "reservation.json", 'utf8', function (err, data) {
	 if (!err){
		
        reservation =JSON.parse(data)
		for (var i = 0; i <reservation.length; i++) {
			
			 if (reservation[i].name == req.params.usernameValue){
				 reservation[i].startDate = req.params.startDateValue;
				 reservation[i].startTime = req.params.startTimeValue;
				 reservation[i].hours = req.params.hourValue;
				 found =1;
			 }
	    }
	 }
	 if (found == 1){
	    var json_str = JSON.stringify( reservation);
        fs.writeFile('reservation.json',json_str, function(err) {
		 if(err){
           throw err;
         }
		 else{
		   console.log(`Reservation has updated`);
		   console.log(json_str);
		   res.send(`Reservation has updated`);
		   res.end();
		}    
	   });
	 }
	 else{
	   console.log(`The user has not reservation, please add.`);
	   res.send(`The user has not reservation, please add.`);
	   res.end();
	}
 });
})

/*API Delete user reservation*/
app.delete('/deleteReservation/:usernameValue/', function (req,res,next) {
	 console.log( "deleteReservation:" );
	 console.log(req.params.usernameValue);
	 let found =0;
     fs.readFile( __dirname + "/" + "reservation.json", 'utf8', function (err, data) {
	 var newReservations = [];
	 if (!err){
        reservation =JSON.parse(data);
		for (var i = 0; i <reservation.length; i++) {
			
			 if (reservation[i].name == req.params.usernameValue){
				 reservation.splice(i,1);
				 found =1;
			 }
	    }
	 }
	 if (found == 1){
	   var json_str = JSON.stringify(reservation);
       fs.writeFile('reservation.json',json_str, function(err) {
		if(err){
           throw err;
        }
		else{
		 res.send(`Reservation has deleteded.`);
		 console.log(`Reservation has deleteded.`);
		 console.log(json_str);
		 res.end();
		}    
	  });
	}
	else{
	   console.log(`The user has not reservation.`);
	   res.send(`The user has not reservation.`);
	   res.end();
	}
 });
})


var server = app.listen(8081, function () {
  var port = server.address().port
  console.log(`Server up at localhost:${port}`);

})