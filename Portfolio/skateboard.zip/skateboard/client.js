    const app = document.getElementById('root');
	
	var requestUser = new XMLHttpRequest();
    requestUser.open("GET", "http://localhost:8081/listUsers",true);
	requestUser.onload = function()
    {
          
		if(this.response.length >0)
		 {
		   var users = JSON.parse(this.response);
		   for(let i = 0; i < users.length; i++){
		      addUserOption(users[i].name);
			  	 
           }
		    
		 }
    } 
	requestUser.send();
	
	//add table
     var table = document.createElement("table");
	 var trNode = table.insertRow();
	 var tdNode = trNode.insertCell();
	 tdNode.innerHTML ="UserName";
	 tdNode = trNode.insertCell();
	 tdNode.innerHTML ="StartDate";
	 tdNode = trNode.insertCell();
	 tdNode.innerHTML ="StartTime";
	 tdNode = trNode.insertCell();
	 tdNode.innerHTML ="Hours";
	 app.appendChild(table);
     const Message = document.createElement('p');
     Message.textContent =' ';
	 app.appendChild( Message);
	 
	 //add user
    function addUser(){
	  var inputUsername= document.getElementById('newUser').value.trim();	
	  if (inputUsername.length > 0)
	  {
		  
        var request1 = new XMLHttpRequest();
        var addUser ='http://localhost:8081/addUser/' + inputUsername; 
        request1.open('post', addUser, true);
	    request1.onload = function()
	    {
		  if(this.response.length >0)
			  alert(this.response);
		  if(this.response =="User has added")
			  addUserOption(inputUsername);
        }
	    request1.send( inputUsername );
	  }
	  else{
		  alert('Please input user name');
	  }
    }
	
	//add reservation
	function addReservation(){
    
	  var obj=document.getElementById('userNameAdd');
      var index=obj.selectedIndex;
      var val = obj.options[index].value;
	  var inputUsername= obj.options[index].value;
      var inputstartDate= document.getElementById('startDate').value.trim();
	  var inputstartTime= document.getElementById('startTime').value.trim();
	  var inputHours= document.getElementById('hours').value.trim();
	
	  if (!IsDate(inputstartDate))
	  { 
		 alert('Please input correct date format(yyyy-mm-dd) and value');
		 return;
	  }
	
	  if(!IsTime(inputstartTime))
	  { 
		alert('Please input correct time format(hh:mm) and value');
	    return;
	  }
	  
	  if(inputHours.length == 0|| isNaN(inputHours)){
         alert(" Hours need correcr number");
         return;
      }
	  
	  var addR ='http://localhost:8081/addReservation/username/'+inputUsername+ '/startDate/'+ inputstartDate+'/startTime/'+inputstartTime+ '/Hours/'+ inputHours; 
      var request2 = new XMLHttpRequest();     
	  request2.open('post',  addR, true);
	  request2.onload = function()
	  {
		 if (this.response.length >0)
		  alert(this.response);
      }
	  request2.send();	
    }
	
	//update reservation
	function updateReservation(){
      var requestUpdate = new XMLHttpRequest();
      var inputUsername=  document.getElementById('userNameUpdate').value.trim();
	  var inputstartDate= document.getElementById('startDateUpdate').value.trim();
	  var inputstartTime= document.getElementById('startTimeUpdate').value.trim();
	  var inputHours= document.getElementById('hoursUpdate').value.trim();
	  if (!IsDate(inputstartDate))
	  { 
		 alert('Please input correct date format(yyyy-mm-dd) and value');
		 return;
	  }
	
	  if(!IsTime(inputstartTime))
	  { 
		alert('Please input correct time format(hh:mm) and value');
	    return;
	  }
	  
	   if(inputHours.length == 0|| isNaN(inputHours)){
         alert(" Hours need correcr number");
         return;
      }
	  
	  var updateURL ='http://localhost:8081/updateReservation/username/'+inputUsername+ '/startDate/'+ inputstartDate+'/startTime/'+inputstartTime+ '/Hours/'+ inputHours; 
      requestUpdate.open('put',  updateURL, true);
	  requestUpdate.onload = function()
	  {
		  if (this.response.length >0)
			  alert(this.response);
      }
	  requestUpdate.send();	
    }
	
	//delete reservation
	function deleteReservation(){
	  var request4 = new XMLHttpRequest();
      var inputUsername= document.getElementById('userNameDelete').value.trim();
	  var deleteURL ='http://localhost:8081/deleteReservation/'+inputUsername; 
      request4.open('DELETE',  deleteURL, true);
	  request4.onload = function()
	  {
		  if (this.response.length >0)
			  alert(this.response);
      }
	  request4.send();		
	}
	
	//list one user reservation
	function listOne(){
	    
		var inputUsername= document.getElementById('oneUser').value.trim();
        var getUser ='http://localhost:8081/listOne/' + inputUsername;
		var requestone = new XMLHttpRequest();
		requestone.open("GET", getUser,true);
		requestone.onload = function()
		{
		   var responsedata = this.response;
		   updateTable(responsedata);
        }
		 requestone.send()
	}
	
	//list all user reservation
	function listAll(){
	   var requestall = new XMLHttpRequest();
	   requestall.open("GET", "http://localhost:8081/listAll",true);
	   requestall.onload = function()
	   {
		   var responsedata = this.response;
		   updateTable(responsedata);
		  
        }
		 requestall.send();  	
	}
	
	//add user in user option
   function addUserOption(inputUsername){
     
	  let useroption1 = document.createElement("option");
	  let username1 = document.createTextNode(inputUsername);
	  useroption1.appendChild(username1);
	  document.getElementById('userNameAdd').appendChild(useroption1);
	  
	  
	  let useroption2 = document.createElement("option");
      let username2 = document.createTextNode(inputUsername);
      useroption2.appendChild(username2);
      document.getElementById('userNameUpdate').appendChild(useroption2);
	  
	  let useroption3 = document.createElement("option");
      let username3 = document.createTextNode(inputUsername);
      useroption3.appendChild(username3);
      document.getElementById('userNameDelete').appendChild(useroption3);
	  
	  let useroption4 = document.createElement("option");
      let username4 = document.createTextNode(inputUsername);
      useroption4.appendChild(username4);
      document.getElementById('oneUser').appendChild(useroption4);
   }
   
   //update reservation table
   function updateTable(responsedata){
	 var len =table.rows.length-1;
	 for (var i = 0; i < len; i++) {
		table.deleteRow(1);
	 }	
	
     if(responsedata == "No reservation")
	   Message.textContent=responsedata;
	 else{
	   var userdata = JSON.parse(responsedata);
	   function sortBy(startDate,startTime) {
         return function(a,b) {
           if(Date.parse(a.startDate ) == Date.parse(b.startDate)) {
			var value1 = a.startTime.split(":");
			var value2 = b.startTime.split(":");
			s1 =  value1[0]*60 + value1[1]*1;
			s2 = value2[0]*60 + value2[1]*1;
			return s1-s2;
		   }
          return Date.parse(a.startDate ) - Date.parse(b.startDate)
          }
         }
		 userdata.sort(sortBy("startDate","startTime"));
		 
		 for (var i = 0; i < userdata.length; i++) {
              trNode = table.insertRow();
              tdNode = trNode.insertCell();
		      tdNode.innerHTML =userdata[i].name;
			  tdNode = trNode.insertCell();
		      tdNode.innerHTML =userdata[i].startDate;
			  tdNode = trNode.insertCell();
			  tdNode.innerHTML =userdata[i].startTime;
			  tdNode = trNode.insertCell();
		      tdNode.innerHTML =userdata[i].hours;
		 }
		 Message.textContent=" ";
	    }   
    }
  
   
   function updateNameSelected(){
	 
		var inputUsername= document.getElementById('userNameUpdate').value.trim();
        var getUser ='http://localhost:8081/listOne/' + inputUsername;
		var requestone = new XMLHttpRequest();
		requestone.open("GET", getUser,true);
		requestone.onload = function()
		{
		   var responsedata = this.response;
		   if(responsedata == "No reservation"){
		     document.getElementById('startDateUpdate').value = " ";
			 document.getElementById('startTimeUpdate').value =  " ";
			 document.getElementById('hoursUpdate').value = " ";
		   }
		   else
	       {
			 var userdata = JSON.parse(responsedata);
			 document.getElementById('startDateUpdate').value =  userdata[0].startDate;
			 document.getElementById('startTimeUpdate').value =  userdata[0].startTime;
			 document.getElementById('hoursUpdate').value =  userdata[0].hours;
				
		  }
		  
        }
		 requestone.send()
	 
    }

   //check date format and value
   function IsDate(mystring) {
      var reg = /^(\d{4})-(\d{1,2})-(\d{1,2})$/;
      var str = mystring;
     // var arr = reg.exec(str);
      if (!(reg.test(str)&& RegExp.$2>=1&& RegExp.$2<=12&& RegExp.$3>=1 && RegExp.$3<=31)){
        return false;
      }
      return true;
   }
   
   // check time format and value
   function IsTime(mystring) {
      var reg = /^(\d{1,2}):(\d{1,2})$/;
      var str = mystring;
     // var arr = reg.exec(str);
      if (!(reg.test(str)&& RegExp.$1>=0&& RegExp.$1<=23&& RegExp.$2>=0 && RegExp.$2<=59)){
       return false;
      }
      return true;
   }
   
 




