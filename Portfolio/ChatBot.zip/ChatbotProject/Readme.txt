***Task***
Tang poetry has become the treasure of Chinese traditional literature. 
So I want to make a chatbot to introduce famous Tang poetry and poets to foreign friends who want to understand Chinese traditional culture. 
Tang Dynasty is a golden age for the development of Chinese poetry. There are a huge number of Tang poetry and many outstanding poets were born. 
I have defined 3 user intents for my chatbot:
 1.Famous Poetry: Introduce the 50 most famous Tang poems.
 2.Famous Poet: Introduce five most famous poets and their representative works
 3.Season Poetry: Appreciate the beauty of the four seasons in Tang poetry.

***Design***
This is a text-based chatbot.The chatbot can receive a user message and povide valid response to that message.
It can hold multiple turn conversation with human users. 
I use a modular structure which is decomposed into three major components:
 1.Language Understander: Use keywords to identify user intent, required information and optional information. Extract needed information from the user message and put the extracted information to the hash table.
 2.Dialogue Management: Based on value extracted from the hash table to decide what should I ask for the missing information or what should I answer.
 3.Response Generation: Based on conversational action returned from dialogue manager to produce the valid responses for each condition.
Scope the components clearly, so I can focus on each component's task.