
package chatbotproject;

import chatbot.infra.Chatbot;
import chatbot.infra.ChatbotGUI;

/**
 * Design a chatbot to introduce famous Tang poetry and poets to foreign friends 
 * who want to understand Chinese traditional culture.
 * @author Bingnan Dong
 */
public class ChatbotProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Chatbot nowChatbot = new Chatbot("Eric", "Chatbot");   //Create a new Chatbot
	ChatbotGUI nowChatbotGUI = new ChatbotGUI(nowChatbot); //Send new Chatbot to the ChatbotGUI which is a interface that allow the user to communicate with chatbot
    }
    
}
