
package user.intent;

import java.util.ArrayList;
import java.util.Hashtable;
import chatbot.component.LanguageUnderstander;

/**
 * Define user intent
 * Keep the track of latest user intent
 * Extract the needed information from user messages and put them in hash table
 * @author Bingnan Dong
 */
public abstract class AbstractUserIntent  {
       Hashtable<String, Object> slotTable; //Store multiple information extracted from the user messages.Based on value extracted from the hash table to control the workflow.
       
       public AbstractUserIntent(String userMsg)  {
               this.slotTable = new Hashtable<String, Object>();
               updateSlotValues(userMsg); 
	}
       
       public String getIntentName() {
               System.out.println("IntentName:"+ this.getClass().getSimpleName());
	       return this.getClass().getSimpleName();
	}
        
       /** 
        * Extract the needed information from user messages and put them in hash table
        * @param userMsg a user's input message 
        * */
       abstract Hashtable<String, Object> extractSlotValuesFromUserMsg(String userMsg); 
       
       /** 
        * Update the slot value in the hash table with the exacteded information from user message
        * @param newMsg a user's input message 
        * */
       public void updateSlotValues(String newMsg){
	      Hashtable<String, Object> localTable = extractSlotValuesFromUserMsg(newMsg);
	      if(!localTable.isEmpty()) { 
                  for(String nowKey: localTable.keySet()) {
		      System.out.println("Update Slot:"+ " "+  nowKey+" = "+localTable.get(nowKey));
		      if(nowKey!=null&&localTable.get(nowKey)!=null) {
			 slotTable.put(nowKey, localTable.get(nowKey));}	
		      }
		}
               else{   // in order to identify a new indent
                    this.slotTable = new Hashtable<String, Object>(); 
               }
	}
	
	public Object getLastestSlotValue(String slotName){
	       return slotTable.get(slotName);
	}
	
	public Hashtable<String, Object> getLatestSlotValues(){
		return slotTable;
	}
	
}
