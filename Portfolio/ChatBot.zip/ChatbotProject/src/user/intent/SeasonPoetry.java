
package user.intent;

import java.util.Hashtable;

/**
 * Extract the needed information for predefined intent "Season Poetry"
 * @author Bingnan Dong
 */
public class SeasonPoetry  extends AbstractUserIntent{
    
    public SeasonPoetry (String userMsg)  {
		super(userMsg);
	}
    
     /**@Override 
        * Extract the season from the user input message to put the result in the hash table
        * @param userMsg the user input message
        * @return   A Hashtable contains key "season"
        */
     public Hashtable<String, Object> extractSlotValuesFromUserMsg(String userMsg){
            Hashtable<String, Object> result = new Hashtable<String, Object>();
	     String[] season = {"spring","summer","autumn","fall","winter"};
             
             for(int i =0 ; i <season.length ;i++)
             if (userMsg.toLowerCase().contains(season[i])){
                  result.put("season", season[i]); 
                  break;
             }
            
             return result;
	}	
}
