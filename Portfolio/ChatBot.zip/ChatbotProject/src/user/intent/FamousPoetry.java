
package user.intent;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Extract the needed information for predefined intent "Famous Poetry"
 * @author Bingnan Dong
 */
public class FamousPoetry  extends AbstractUserIntent{
     
    public FamousPoetry (String userMsg)  {
		super(userMsg);
	}
    
     /**@Override 
        * Extract the number of poet and the type of poem from the user input message to put the result in the hash table
        * @param userMsg the user input message
        * @return   A Hashtable contains key "poemNumber" and "poemType"
        */
     public Hashtable<String, Object> extractSlotValuesFromUserMsg(String userMsg){
            Hashtable<String, Object> result = new Hashtable<String, Object>();
	     
            /* identify required information: poem number*/
             Pattern pattern = Pattern.compile("[0-9]+");
             Matcher isNum = pattern.matcher(userMsg);
             if (isNum.matches()) {
               if(Integer.valueOf(userMsg)>=1 && Integer.valueOf(userMsg)<=50){
                    result.put("poemNumber",userMsg);
               }
             }
             /* identify option information: friendship*/
             if (userMsg.toLowerCase().contains("friendship")){
                  result.put("poemType", "friendship"); 
                 
             }
              /* identify option information:moon*/
             if (userMsg.toLowerCase().contains("moon")){
                  result.put("poemType", "moon"); 
              }
            
             return result;
	}		
}
