package chatbot.component;

import chatbot.infra.Chatbot;
import user.intent.AbstractUserIntent;

/**
 * Based on value extracted from the hash table to control the workflow
 * @author Bingnan Dong
 */
public class DialogManager {

	private Chatbot chatbot;
	
	public DialogManager(Chatbot chatbot) {
		this.chatbot = chatbot;
	}
        
         /**
        * Based on value extracted from the hash table to decide
        * what should I ask for the missing information or what should I answer.
        * @param nowUserIntent the predefined user intent
        * @return the conversational action
        */
	public String getConversationalAction(AbstractUserIntent nowUserIntent) {
	       if(nowUserIntent==null) {//no user intent detected yet
			return "ask-intent";
	      }
              else if (nowUserIntent.getIntentName().equals("FamousPoet")){
                        if(nowUserIntent.getLastestSlotValue("name")!=null && nowUserIntent.getLastestSlotValue("poetNumber")!=null )
                           return "answer_poetnumber";
                        if(nowUserIntent.getLastestSlotValue("name")==null)
                           return "ask-name";
                        if(nowUserIntent.getLastestSlotValue("poetNumber")==null)
                           return "ask-poetnumber";
             }else if (nowUserIntent.getIntentName().equals("FamousPoetry")  ){
                         if(nowUserIntent.getLastestSlotValue("poemNumber")!=null && nowUserIntent.getLastestSlotValue("poemType")!=null)
                           return "answer_poemtype"; 
                         else if(nowUserIntent.getLastestSlotValue("poemNumber")!=null)
                           return "answer_poemnumber";
                         else
                           return "ask-poemnumber"; 
             }else if (nowUserIntent.getIntentName().equals("SeasonPoetry")){
                         if(nowUserIntent.getLastestSlotValue("season")!=null)
                           return "answer_season"; 
                         else
                           return "ask-season"; 
             }
             return ""; 	
	}

}
