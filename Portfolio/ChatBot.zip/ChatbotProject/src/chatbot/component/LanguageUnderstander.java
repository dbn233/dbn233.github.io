
package chatbot.component;

import chatbot.infra.Chatbot;
import user.intent.AbstractUserIntent;
import user.intent.FamousPoet;
import user.intent.FamousPoetry;
import user.intent.SeasonPoetry;

/**
 * Convert an English sentence to the form that computer can process
 * Use keywords to identify user intent, required information and optional information.
 * @author Bingnan Dong
 */
public class LanguageUnderstander {

	private Chatbot chatbot;	
	private AbstractUserIntent latestUserIntent;
	
        public LanguageUnderstander(Chatbot chatbot) {
		this.chatbot = chatbot;
	}
        
        /**
        * Keep the track of latest user intent
        * @param nowInputText a user's input message 
        */
	public AbstractUserIntent getLatestUserIntent(String nowInputText)  {
		detectUserIntent(nowInputText);
		return latestUserIntent;
	}
        
        /**
        * Detect if a user's message contains the predefined intents:"FamousPoet","SeasonPoetry" and "FamousPoetry"
        * @param nowInputText a user's input message 
        */
	public void detectUserIntent(String nowInputText) {
		if(isUserIntent(nowInputText, "FamousPoet")) {
			System.out.println("Detected User Intent: FamousPoet");
			if(latestUserIntent!=null&&latestUserIntent.getIntentName().equals("FamousPoet")) {//intent continues
                            latestUserIntent.updateSlotValues(nowInputText);
			}else {//new intent
				System.out.println("Updated User Intent: FamousPoet");
				latestUserIntent = new FamousPoet(nowInputText); 
			}	
		}else if(isUserIntent(nowInputText, "SeasonPoetry")){
			System.out.println("Detected User Intent:SeasonPoetry");
			if(latestUserIntent!=null&&latestUserIntent.getIntentName().equals("SeasonPoetry")) {//intent continues
				latestUserIntent.updateSlotValues(nowInputText);
			}else {//new intent
				System.out.println("Updated User Intent: SeasonPoetry");
				latestUserIntent = new SeasonPoetry(nowInputText);
			}
                }else if(isUserIntent(nowInputText, "FamousPoetry")){
			System.out.println("Detected User Intent: FamousPoetry");
			if(latestUserIntent!=null&&latestUserIntent.getIntentName().equals("FamousPoetry")) {//intent continues
				latestUserIntent.updateSlotValues(nowInputText);
			}else {//new intent
				System.out.println("Updated User Intent: FamousPoetry");
				latestUserIntent = new FamousPoetry(nowInputText);
			}
		}else {
			System.out.println("Detected User Intent: Else");
			if(latestUserIntent!=null&&latestUserIntent.getIntentName().equals("FamousPoet")) {
				latestUserIntent.updateSlotValues(nowInputText);
			}else if(latestUserIntent!=null&&latestUserIntent.getIntentName().equals("FamousPoetry")) {
				latestUserIntent.updateSlotValues(nowInputText);
			}else if(latestUserIntent!=null&&latestUserIntent.getIntentName().equals("SeasonPoetry")) {
				latestUserIntent.updateSlotValues(nowInputText);
			}
		}
		
	}

       /**
        * Take a user's message as input and use keywords to identify user intent 
        * @param nowInputText a user's input message 
        * @param userIntentName  one of three predefined intents: "FamousPoet" ,"SeasonPoetry"and "FamousPoetry"
        * @return If the identified intent equals to the given intent (String userIntentName), this method returns true. It returns false otherwise.
        */
	private boolean isUserIntent(String nowInputText, String userIntentName) {
		
                Boolean findUserIntent = false;
                if(userIntentName.equals("FamousPoet")){
                   if( findKeyword(nowInputText, "introduce") >= 0 && (findKeyword(nowInputText, "poet") >=0)||  findKeyword(nowInputText, "poets")>=0){
                       findUserIntent = true;
                   }
                   
                  else if( findKeyword(nowInputText, "know") >= 0 && (findKeyword(nowInputText, "poet") >=0)||findKeyword(nowInputText, "poets") >=0){
                       findUserIntent = true;
                   }
                 
                  else if( findKeyword(nowInputText, "tell") >= 0 && (findKeyword(nowInputText, "poet") >=0)|| findKeyword(nowInputText, "poets") >=0){
                       findUserIntent = true;
                  }   
                   else if( findKeyword(nowInputText, "learn about") >= 0 && (findKeyword(nowInputText, "poet") >=0)|| findKeyword(nowInputText, "poets") >=0){
                       findUserIntent = true;
                   }  
                    else if( findKeyword(nowInputText, "understand") >= 0 && (findKeyword(nowInputText, "poet") >=0)|| findKeyword(nowInputText, "poets") >=0){
                       findUserIntent = true;
                   }   
                   
                } else if(userIntentName.equals("SeasonPoetry")){
                   if( findKeyword(nowInputText, "introduce") >= 0 &&( findKeyword(nowInputText, "season") >=0 ||findKeyword(nowInputText, "seasons") >=0 || findKeyword(nowInputText, "spring") >=0 || findKeyword(nowInputText, "summer") >=0 || findKeyword(nowInputText, "autumn") >=0|| findKeyword(nowInputText, "fall") >=0 || findKeyword(nowInputText, "winter") >=0) && (findKeyword(nowInputText, "poem") >=0||findKeyword(nowInputText, "poems" ) >=0 || findKeyword(nowInputText, "poetry") >=0) ){
                     findUserIntent = true;
                   }
                   else  if( findKeyword(nowInputText, "know") >= 0 &&( findKeyword(nowInputText, "season") >=0 ||findKeyword(nowInputText, "seasons") >=0 || findKeyword(nowInputText, "spring") >=0 || findKeyword(nowInputText, "summer") >=0 || findKeyword(nowInputText, "autumn") >=0|| findKeyword(nowInputText, "fall") >=0 || findKeyword(nowInputText, "winter") >=0) && (findKeyword(nowInputText, "poem") >=0||findKeyword(nowInputText, "poems" ) >=0 || findKeyword(nowInputText, "poetry") >=0) ){
                     findUserIntent = true;
                   }
                   else  if( findKeyword(nowInputText, "tell") >= 0 &&( findKeyword(nowInputText, "season") >=0 ||findKeyword(nowInputText, "seasons") >=0 || findKeyword(nowInputText, "spring") >=0 || findKeyword(nowInputText, "summer") >=0 || findKeyword(nowInputText, "autumn") >=0|| findKeyword(nowInputText, "fall") >=0 || findKeyword(nowInputText, "winter") >=0) && (findKeyword(nowInputText, "poem") >=0||findKeyword(nowInputText, "poems" ) >=0 || findKeyword(nowInputText, "poetry") >=0) ){
                        findUserIntent = true;
                   }
                   else  if( findKeyword(nowInputText, "learn about") >= 0 && ( findKeyword(nowInputText, "season") >=0 ||findKeyword(nowInputText, "seasons") >=0 || findKeyword(nowInputText, "spring") >=0 || findKeyword(nowInputText, "summer") >=0 || findKeyword(nowInputText, "autumn") >=0|| findKeyword(nowInputText, "fall") >=0 || findKeyword(nowInputText, "winter") >=0) &&  (findKeyword(nowInputText, "poem") >=0||findKeyword(nowInputText, "poems") >=0 ||findKeyword(nowInputText, "poetry") >=0) ){
                       findUserIntent = true;
                   }
                   else  if( findKeyword(nowInputText, "understand") >= 0 && ( findKeyword(nowInputText, "season") >=0 ||findKeyword(nowInputText, "seasons") >=0 || findKeyword(nowInputText, "spring") >=0 || findKeyword(nowInputText, "summer") >=0 || findKeyword(nowInputText, "autumn") >=0|| findKeyword(nowInputText, "fall") >=0 || findKeyword(nowInputText, "winter") >=0) &&  (findKeyword(nowInputText, "poem") >=0||findKeyword(nowInputText, "poems") >=0 ||findKeyword(nowInputText, "poetry") >=0) ){
                       findUserIntent = true;
                   }
                }
                else if(userIntentName.equals("FamousPoetry")){
                   if( findKeyword(nowInputText, "introduce") >= 0 && (findKeyword(nowInputText, "poem") >=0 ||findKeyword(nowInputText, "poems") >=0  ||findKeyword(nowInputText, "poetry") >=0)){
                       findUserIntent = true;
                   }
                  
                  else if( findKeyword(nowInputText, "know") >= 0 && (findKeyword(nowInputText, "poem") >=0 ||findKeyword(nowInputText, "poems") >=0 ||findKeyword(nowInputText, "poetry") >=0 )){
                       findUserIntent = true;
                   }
                 
                  else if( findKeyword(nowInputText, "tell") >= 0 && (findKeyword(nowInputText, "poem") >=0 ||findKeyword(nowInputText, "poems") >=0 ||findKeyword(nowInputText, "poetry") >=0)){
                       findUserIntent = true;
                         
                   }
                  else if( findKeyword(nowInputText, "learn about") >= 0 && (findKeyword(nowInputText, "poem") >=0 ||findKeyword(nowInputText, "poems") >=0 ||findKeyword(nowInputText, "poetry") >=0)){
                       findUserIntent = true;
                   }
                  else if( findKeyword(nowInputText, "understand") >= 0 && (findKeyword(nowInputText, "poem") >=0 ||findKeyword(nowInputText, "poems") >=0 ||findKeyword(nowInputText, "poetry") >=0)){
                       findUserIntent = true;
                   }
                }
		return findUserIntent;
		
	}
        
        /**
	 * Search for one word in phrase. The search is not case sensitive. This method
	 * will check that the given goal is not a substring of a longer string (so, for
	 * example, "I know" does not contain "no"). The search begins at the beginning of the string.
	 * @param statement the string to search
	 * @param goal the string to search for
	 * @return the index of the first occurrence of goal in statement or -1 if it's  not found
	 *        
	 */
	public static int findKeyword(String statement, String goal) {
		
                String phrase = statement.trim().toLowerCase();
		goal = goal.toLowerCase();
                int startPos = 0;
		// The only change to incorporate the startPos is in  the line below
		int psn = phrase.indexOf(goal, startPos);

		// Refinement--make sure the goal isn't part of a word
		while (psn >= 0) {
			// Find the string of length 1 before and after  the word
			String before = " ", after = " ";
			if (psn > 0) {
				before = phrase.substring(psn - 1, psn);
			}
			if (psn + goal.length() < phrase.length()) {
				after = phrase.substring(psn + goal.length(), psn + goal.length() + 1);
			}

			// If before and after aren't letters, we've found the word
			if (((before.compareTo("a") < 0) || (before.compareTo("z") > 0)) // before is not a
																				// letter
					&& ((after.compareTo("a") < 0) || (after.compareTo("z") > 0))) {
				return psn;
			}

			// The last position didn't work, so let's find the next, if there is one.
			psn = phrase.indexOf(goal, psn + 1);

		}
		return -1;
	}
}