
package chatbot.infra;

import chatbot.component.DialogManager;
import chatbot.component.LanguageUnderstander;
import chatbot.component.ResponseGenerator;
import user.intent.AbstractUserIntent;

/**
 * This is a task-oriented text-based chatbot which is decomposed into three major Components: 
 * Language Understander, Dialogue Manager, Response Generator
 * The chatbot can receive a user message and povide valid response to that message
 * It can hold multiple turn conversation with human users.
 * @author Bingnan Dong
 */
public class Chatbot {
	
	private String userName = "Eric";
	private String botName = "Chatbot";
	
	private LanguageUnderstander lu;
	private DialogManager dm;
	private ResponseGenerator rg;
	
	
	public Chatbot(String userName, String botName) {
		
		this.userName = userName;
		this.botName = botName;
		
		this.lu = new LanguageUnderstander(this);
		this.dm = new DialogManager(this);
		this.rg = new ResponseGenerator(this);
		
	}
	/**
        * Identify the user intent from the user message
        * Put the extracted information to the hash table
        * Based on value extracted from the hash table to decide conversational action
        * @param nowUserIntent the user input message
        * @return  valid responses for each cconversational action.
        */
	public String getResponse(String nowInputText) {
		
		AbstractUserIntent nowUserIntent = lu.getLatestUserIntent(nowInputText);
		if(nowUserIntent!=null) {
			System.out.println("Latest User Intent: "+nowUserIntent.getIntentName());
		}else {
			System.out.println("Latest User Intent: no intent detected yet");
		}
		
		String nowConversationalAction = dm.getConversationalAction(nowUserIntent);
		System.out.println("nowConversationalAction: "+nowConversationalAction);
		
		String finalResponse = rg.getResponse(nowUserIntent, nowConversationalAction);
                
		return finalResponse;
	}

        
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getBotName() {
		return botName;
	}

	public void setBotName(String botName) {
		this.botName = botName;
	}
}

